"use client";

import Link from 'next/link';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/use-cart';

export function CartButton() {
  const { totalItems } = useCart();

  return (
    <Button variant="ghost" size="icon" asChild>
      <Link href="/cart">
        <ShoppingCart className="h-5 w-5" />
        {totalItems > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">
            {totalItems}
          </span>
        )}
        <span className="sr-only">عربة التسوق</span>
      </Link>
    </Button>
  );
}
