"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import type { StoreSettings } from "@/lib/types";
import { useFirestore, errorEmitter, FirestorePermissionError } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { Loader2, Save } from "lucide-react";

interface SettingsFormProps {
  settings: StoreSettings;
}

export function SettingsForm({ settings }: SettingsFormProps) {
    const { toast } = useToast();
    const firestore = useFirestore();
    const [isSaving, setIsSaving] = useState(false);

    const [name, setName] = useState(settings.name);
    const [slogan, setSlogan] = useState(settings.slogan);
    const [address, setAddress] = useState(settings.address);
    const [phone1, setPhone1] = useState(settings.phone1);
    const [phone2, setPhone2] = useState(settings.phone2);
    const [mapsLink, setMapsLink] = useState(settings.mapsLink);
    const [storeStatus, setStoreStatus] = useState(settings.storeStatus);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!firestore) return;
        setIsSaving(true);

        const updatedSettings: StoreSettings = {
            name,
            slogan,
            address,
            phone1,
            phone2,
            mapsLink,
            workingHours: settings.workingHours,
            deliveryPolicy: settings.deliveryPolicy,
            storeStatus,
        };

        const settingsRef = doc(firestore, 'stores', 'default');
        setDoc(settingsRef, updatedSettings, { merge: true })
            .catch(async (error) => {
                const permissionError = new FirestorePermissionError({
                    path: settingsRef.path,
                    operation: 'update',
                    requestResourceData: updatedSettings,
                });
                errorEmitter.emit('permission-error', permissionError);
            });

        toast({
            title: "تم حفظ الإعدادات بنجاح",
        });
        setIsSaving(false);
    }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>المعلومات الأساسية</CardTitle>
          <CardDescription>
            تعديل معلومات التواصل والحالة العامة للمتجر.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">اسم المتجر</Label>
              <Input id="name" value={name} onChange={e => setName(e.target.value)} />
            </div>
             <div className="space-y-2">
              <Label htmlFor="slogan">شعار المتجر</Label>
              <Input id="slogan" value={slogan} onChange={e => setSlogan(e.target.value)} />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">العنوان</Label>
            <Textarea id="address" value={address} onChange={e => setAddress(e.target.value)} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone1">الهاتف الأساسي</Label>
              <Input id="phone1" value={phone1} onChange={e => setPhone1(e.target.value)} />
            </div>
             <div className="space-y-2">
              <Label htmlFor="phone2">الهاتف الثانوي</Label>
              <Input id="phone2" value={phone2} onChange={e => setPhone2(e.target.value)} />
            </div>
          </div>
          
           <div className="space-y-2">
              <Label htmlFor="mapsLink">رابط الموقع (خرائط جوجل)</Label>
              <Input id="mapsLink" value={mapsLink} onChange={e => setMapsLink(e.target.value)} dir="ltr" />
            </div>

          <div className="flex items-center space-x-2 space-x-reverse">
            <Switch 
                id="store-status" 
                checked={storeStatus === 'open'} 
                onCheckedChange={(checked) => setStoreStatus(checked ? 'open' : 'closed')} 
            />
            <Label htmlFor="store-status">
              حالة المتجر: {storeStatus === 'open' ? 'مفتوح' : 'مغلق'}
            </Label>
          </div>
          
           <Button type="submit" disabled={isSaving} className="w-full md:w-auto">
                {isSaving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
                حفظ التغييرات
            </Button>
        </CardContent>
      </Card>
    </form>
  );
}
