"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Upload, Save, Loader2, Plus, Trash2 } from "lucide-react";
import { CATEGORIES } from "@/lib/data";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { collection, addDoc } from 'firebase/firestore';
import { useFirestore } from '@/firebase/provider';
import { useToast } from '@/hooks/use-toast';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { Switch } from '@/components/ui/switch';
import type { Size } from '@/lib/types';

export default function NewProductPage() {
  const router = useRouter();
  const { toast } = useToast();
  const firestore = useFirestore();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('juices');
  const [sizes, setSizes] = useState<Size[]>([{ name: 'صغير', price: 0 }]);
  const [featured, setFeatured] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSizeChange = (index: number, field: 'name' | 'price', value: string | number) => {
    const newSizes = [...sizes];
    if (field === 'price') {
      newSizes[index][field] = Number(value);
    } else {
      newSizes[index][field] = value as any;
    }
    setSizes(newSizes);
  };

  const addSize = () => {
    setSizes([...sizes, { name: 'كبير', price: 0 }]);
  };

  const removeSize = (index: number) => {
    setSizes(sizes.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firestore) return;
    setIsSaving(true);

    const productData = {
      name,
      description,
      category,
      sizes,
      featured,
      imageId: 'mango-juice', // صورة افتراضية حاليا
      createdAt: new Date().toISOString(),
    };

    const productsCol = collection(firestore, 'products');
    addDoc(productsCol, productData)
      .catch(async (error) => {
        const permissionError = new FirestorePermissionError({
          path: productsCol.path,
          operation: 'create',
          requestResourceData: productData,
        });
        errorEmitter.emit('permission-error', permissionError);
      });

    toast({ title: "تم إضافة المنتج بنجاح!" });
    router.push('/admin/products');
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8 font-headline">إضافة منتج جديد</h1>
      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>تفاصيل المنتج</CardTitle>
            <CardDescription>املأ الحقول أدناه لإضافة منتج جديد إلى قائمتك.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="product-name">اسم المنتج</Label>
              <Input id="product-name" placeholder="مثال: عصير مانجو" value={name} onChange={e => setName(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="product-description">وصف المنتج</Label>
              <Textarea id="product-description" placeholder="وصف قصير وجذاب للمنتج..." value={description} onChange={e => setDescription(e.target.value)} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="product-category">القسم</Label>
                 <Select dir="rtl" value={category} onValueChange={setCategory}>
                  <SelectTrigger id="product-category">
                    <SelectValue placeholder="اختر قسمًا" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(category => (
                        <SelectItem key={category.id} value={category.id}>{category.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
               <div className="flex items-center space-x-2 space-x-reverse pt-8">
                  <Switch id="featured-switch" checked={featured} onCheckedChange={setFeatured} />
                  <Label htmlFor="featured-switch">منتج مميز؟</Label>
                </div>
            </div>

            <div className="space-y-4 rounded-md border p-4">
                <Label>الأحجام والأسعار</Label>
                {sizes.map((size, index) => (
                    <div key={index} className="grid grid-cols-3 gap-2 items-center">
                        <Input value={size.name} onChange={e => handleSizeChange(index, 'name', e.target.value)} placeholder="اسم الحجم" required />
                        <Input type="number" value={size.price} onChange={e => handleSizeChange(index, 'price', e.target.value)} placeholder="السعر" required />
                        {sizes.length > 1 && <Button type="button" variant="ghost" size="icon" onClick={() => removeSize(index)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                    </div>
                ))}
                <Button type="button" variant="outline" onClick={addSize} className="w-full">
                    <Plus className="ml-2 h-4 w-4" />
                    إضافة حجم آخر
                </Button>
            </div>

             <Button type="submit" disabled={isSaving} className="w-full md:w-auto">
                {isSaving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
                حفظ المنتج
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
