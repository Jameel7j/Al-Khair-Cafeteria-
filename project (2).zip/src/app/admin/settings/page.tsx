"use client";

import { SettingsForm } from "@/components/admin/SettingsForm";
import { STORE_SETTINGS } from "@/lib/data";
import { useDoc, useFirestore, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { Loader2 } from "lucide-react";
import type { StoreSettings } from "@/lib/types";

export default function AdminSettingsPage() {
  const firestore = useFirestore();
  
  const settingsRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return doc(firestore, 'stores', 'default');
  }, [firestore]);

  const { data: settings, isLoading } = useDoc<StoreSettings>(settingsRef);

  if (isLoading) {
    return <Loader2 className="mx-auto mt-16 h-8 w-8 animate-spin" />;
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8 font-headline">إعدادات المتجر</h1>
      <SettingsForm settings={settings || STORE_SETTINGS} />
    </div>
  );
}
