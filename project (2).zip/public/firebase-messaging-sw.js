// This file intentionally left blank. It will be populated in a future step.
// For now, its existence is required to register the service worker.
